
# SIVIT – Federated Multimodal Search (Interview-Ready Demo)

**Highlights**
- Privacy-first architecture with on-device embeddings (stdlib TF-IDF-ish).
- Provider adapter framework (plug new providers easily).
- Explainable ranking: semantic similarity + price + rating.
- Deduplication across providers (title+snippet canonicalization).
- End-to-end CLI: <2s target for small batches (local).

## Run
```bash
cd sivit
python -m sivit.main "lightweight laptop 16gb ram" --topk 5
python -m sivit.main "best headphones with anc" --topk 5
```

## Extend
- Replace `utils/multimodal.py` with real on-device ASR / image captioning.
- Implement real providers by subclassing `providers/base.py`.
- Swap `core/embeddings.py` with a proper on-device embedding model.
