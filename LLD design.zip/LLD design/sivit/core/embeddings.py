
import math
import re
from typing import List, Dict, Iterable
from collections import Counter, defaultdict

TOKEN_RE = re.compile(r"[A-Za-z0-9_]+")

def tokenize(text: str) -> List[str]:
    return [t.lower() for t in TOKEN_RE.findall(text or "")]

class OnDeviceEmbedder:
    """Lightweight TF-IDF-like embedder with stdlib only.
    Build vocabulary on the fly for a small corpus and return sparse vectors.
    """
    def __init__(self):
        self.df = defaultdict(int)
        self.n_docs = 0

    def fit(self, docs: Iterable[str]):
        seen_docs = []
        for d in docs:
            toks = set(tokenize(d))
            seen_docs.append(toks)
        self.n_docs = len(seen_docs)
        for toks in seen_docs:
            for t in toks:
                self.df[t] += 1

    def vectorize(self, text: str) -> Dict[str, float]:
        toks = tokenize(text)
        tf = Counter(toks)
        vec = {}
        for term, f in tf.items():
            df = self.df.get(term, 0) or 1
            idf = math.log((1 + self.n_docs) / (1 + df)) + 1.0
            vec[term] = (f / max(1, len(toks))) * idf
        return vec

    @staticmethod
    def cosine(a: Dict[str, float], b: Dict[str, float]) -> float:
        if not a or not b:
            return 0.0
        # dot
        common = set(a.keys()) & set(b.keys())
        dot = sum(a[t]*b[t] for t in common)
        na = math.sqrt(sum(v*v for v in a.values()))
        nb = math.sqrt(sum(v*v for v in b.values()))
        if na == 0 or nb == 0:
            return 0.0
        return dot / (na * nb)
