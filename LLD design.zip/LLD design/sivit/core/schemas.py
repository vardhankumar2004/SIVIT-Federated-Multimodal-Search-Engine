
from dataclasses import dataclass, field
from typing import List, Dict, Optional
import time

@dataclass
class UnifiedQuery:
    text: str
    # Placeholders for multimodal inputs (already converted on-device)
    # In a real system, audio_path/image_path would be inputs; here we pass derived text.
    source: str = "text"  # 'text' | 'voice' | 'image'
    metadata: Dict = field(default_factory=dict)

@dataclass
class ProviderResult:
    id: str
    title: str
    snippet: str
    url: str
    price: Optional[float] = None
    rating: Optional[float] = None  # 0-5
    provider: str = "unknown"
    raw: Dict = field(default_factory=dict)

@dataclass
class ScoredResult:
    result: ProviderResult
    score: float
    reasons: Dict[str, float]  # e.g., {"semantic": 0.78, "price": 0.1, "rating": 0.12}
    latency_ms: int = 0

@dataclass
class AggregatedResponse:
    query: UnifiedQuery
    results: List[ScoredResult]
    latency_ms: int
    deduped_count: int = 0
    timestamp: float = field(default_factory=lambda: time.time())
