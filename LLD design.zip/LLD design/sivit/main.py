
import argparse, os, json
from .core.schemas import UnifiedQuery
from .providers.mock_a import ProviderA
from .providers.mock_b import ProviderB
from .pipelines.aggregator import Aggregator
from .pipelines.ranking import Ranker
from .utils.explain import format_explanation

def run_cli():
    parser = argparse.ArgumentParser(description="SIVIT – Federated Multimodal Search (Interview Demo)")
    parser.add_argument("query", type=str, help="text query (or derived from voice/image)")
    parser.add_argument("--mode", choices=["text","voice","image"], default="text")
    parser.add_argument("--topk", type=int, default=5)
    args = parser.parse_args()

    data_path = os.path.join(os.path.dirname(__file__), "data", "mock.json")
    providers = [ProviderA(data_path), ProviderB(data_path)]
    aggr = Aggregator(providers, ranker=Ranker())

    uq = UnifiedQuery(text=args.query, source=args.mode, metadata={})
    resp = aggr.search(uq, top_k=args.topk)

    print(json.dumps({
        "query": uq.text,
        "source": uq.source,
        "latency_ms": resp.latency_ms,
        "deduped": resp.deduped_count,
        "results": [
            {
                "provider": s.result.provider,
                "title": s.result.title,
                "url": s.result.url,
                "price": s.result.price,
                "rating": s.result.rating,
                "score": round(s.score, 4),
                "why": format_explanation(s),
            }
            for s in resp.results
        ]
    }, indent=2))

if __name__ == "__main__":
    run_cli()
