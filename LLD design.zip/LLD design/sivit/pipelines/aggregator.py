
import time
from typing import List
from ..core.schemas import UnifiedQuery, AggregatedResponse, ScoredResult, ProviderResult
from .dedup import deduplicate
from .ranking import Ranker

class Aggregator:
    def __init__(self, providers: List, ranker: Ranker | None = None):
        self.providers = providers
        self.ranker = ranker or Ranker()

    def search(self, q: UnifiedQuery, top_k: int = 10) -> AggregatedResponse:
        t0 = time.time()
        # Fan-out to providers (sequential here; could be async/threaded)
        all_results: List[ProviderResult] = []
        for p in self.providers:
            try:
                res = p.search(q)
                all_results.extend(res)
            except Exception as e:
                # In interview: discuss provider timeouts & circuit breakers
                pass

        before = len(all_results)
        deduped = deduplicate(all_results)
        deduped_count = before - len(deduped)

        ranked: List[ScoredResult] = self.ranker.rank(q, deduped)[:top_k]

        return AggregatedResponse(
            query=q,
            results=ranked,
            latency_ms=int((time.time() - t0) * 1000),
            deduped_count=deduped_count,
        )
