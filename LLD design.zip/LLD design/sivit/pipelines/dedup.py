
from typing import List, Tuple
from ..core.schemas import ProviderResult

def canonical_key(r: ProviderResult) -> Tuple[str, str]:
    # Normalize title+snippet for dedup; URLs often differ across providers
    t = (r.title or "").strip().lower()
    s = (r.snippet or "").strip().lower()
    return (t, s)

def deduplicate(results: List[ProviderResult]) -> List[ProviderResult]:
    seen = set()
    out = []
    for r in results:
        key = canonical_key(r)
        if key in seen:
            continue
        seen.add(key)
        out.append(r)
    return out
