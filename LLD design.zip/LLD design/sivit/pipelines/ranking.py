
import time
from typing import List, Dict
from ..core.schemas import UnifiedQuery, ProviderResult, ScoredResult
from ..core.embeddings import OnDeviceEmbedder

class Ranker:
    def __init__(self, w_semantic: float = 0.75, w_price: float = 0.15, w_rating: float = 0.10):
        self.w_sem = w_semantic
        self.w_price = w_price
        self.w_rating = w_rating
        self.embedder = OnDeviceEmbedder()

    def _price_score(self, price: float) -> float:
        # Lower is better; simple bounded transform
        if price is None:
            return 0.0
        return 1.0 / (1.0 + price / 1000.0)

    def _rating_score(self, rating: float) -> float:
        if rating is None:
            return 0.0
        return max(0.0, min(1.0, rating / 5.0))

    def rank(self, q: UnifiedQuery, items: List[ProviderResult]) -> List[ScoredResult]:
        t0 = time.time()
        docs = [q.text] + [f"{r.title} {r.snippet}" for r in items]
        self.embedder.fit(docs)
        qv = self.embedder.vectorize(q.text)

        scored: List[ScoredResult] = []
        for r in items:
            rv = self.embedder.vectorize(f"{r.title} {r.snippet}")
            sem = self.embedder.cosine(qv, rv)
            p = self._price_score(r.price) if r.price is not None else 0.0
            rt = self._rating_score(r.rating) if r.rating is not None else 0.0
            score = self.w_sem*sem + self.w_price*p + self.w_rating*rt
            scored.append(ScoredResult(result=r, score=score, reasons={"semantic": sem, "price": p, "rating": rt}))
        # sort high-to-low
        scored.sort(key=lambda x: x.score, reverse=True)
        # Attach latency per item (local ranking latency)
        latency_ms = int((time.time() - t0) * 1000)
        for s in scored:
            s.latency_ms = latency_ms
        return scored
