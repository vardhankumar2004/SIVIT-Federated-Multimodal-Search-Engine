
from typing import List
from ..core.schemas import UnifiedQuery, ProviderResult

class SearchProvider:
    name = "base"
    def search(self, q: UnifiedQuery) -> List[ProviderResult]:
        raise NotImplementedError
