
import json, time
from typing import List
from ..core.schemas import UnifiedQuery, ProviderResult
from .base import SearchProvider

class ProviderA(SearchProvider):
    name = "ProviderA"
    def __init__(self, path:str):
        with open(path, "r") as f:
            self.data = json.load(f)

    def search(self, q: UnifiedQuery) -> List[ProviderResult]:
        t0 = time.time()
        bucket = "price_laptops" if "laptop" in q.text.lower() else "headphones"
        out = []
        for r in self.data.get(bucket, []):
            out.append(ProviderResult(
                id=r["id"], title=r["title"], snippet=r["snippet"], url=r["url"],
                price=r.get("price"), rating=r.get("rating"), provider=self.name, raw=r
            ))
        # Simulate provider latency
        time.sleep(0.05)
        return out
