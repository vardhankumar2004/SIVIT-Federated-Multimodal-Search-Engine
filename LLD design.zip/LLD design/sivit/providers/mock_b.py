
import json, time
from typing import List
from ..core.schemas import UnifiedQuery, ProviderResult
from .base import SearchProvider

class ProviderB(SearchProvider):
    name = "ProviderB"
    def __init__(self, path:str):
        with open(path, "r") as f:
            self.data = json.load(f)

    def search(self, q: UnifiedQuery) -> List[ProviderResult]:
        time.sleep(0.03)
        bucket = "headphones" if "headphone" in q.text.lower() else "price_laptops"
        return [ProviderResult(
            id=r["id"], title=r["title"], snippet=r["snippet"], url=r["url"],
            price=r.get("price"), rating=r.get("rating"), provider=self.name, raw=r
        ) for r in self.data.get(bucket, [])]
