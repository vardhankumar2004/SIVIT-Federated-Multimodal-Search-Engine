
from ..core.schemas import ScoredResult

def format_explanation(sr: ScoredResult) -> str:
    rs = sr.reasons
    return f"semantic={rs.get('semantic',0):.2f}, price={rs.get('price',0):.2f}, rating={rs.get('rating',0):.2f}"
