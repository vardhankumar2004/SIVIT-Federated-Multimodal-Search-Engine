
# In a real deployment, you'd replace these with on-device ASR and image captioning/CLIP models.
# Here we provide minimal placeholders to keep the pipeline intact.
def transcribe(audio_path: str) -> str:
    return "transcribed audio query"

def describe_image(image_path: str) -> str:
    return "image describing text"
